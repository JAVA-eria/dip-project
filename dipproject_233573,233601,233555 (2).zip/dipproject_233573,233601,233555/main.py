"""
========================================================
Real-Time Image Processing Lab with ML Classification
Digital Image Processing - Semester Project
========================================================
Libraries: OpenCV, NumPy, scikit-learn
Run webcam mode:
    python main.py

Run image file mode:
    python main.py --image input.jpg

Controls:
    Press keys shown on screen to toggle filters
    Press W to save processed result
    Press C to toggle ML classification
========================================================
"""

import cv2
import numpy as np
import argparse
import os
from datetime import datetime
import pickle
import json

# ML/AI Libraries
try:
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.preprocessing import StandardScaler
    from sklearn.neighbors import KNeighborsClassifier
    ML_AVAILABLE = True
    print("[INFO] scikit-learn loaded successfully")
except ImportError:
    ML_AVAILABLE = False
    print("[WARNING] scikit-learn not available. Install with: pip install scikit-learn")


class MLClassifier:
    """Simple ML-based image classifier using Random Forest"""
    
    def __init__(self):
        if not ML_AVAILABLE:
            self.model = None
            self.enabled = False
            return
        
        print("[ML] Initializing ML Classifier...")
        
        # Create simple pre-trained model
        self.model = RandomForestClassifier(n_estimators=50, random_state=42)
        self.scaler = StandardScaler()
        self.enabled = True
        
        # Simple object categories based on color/texture features
        self.categories = [
            "Person/Face",
            "Indoor Scene",
            "Outdoor/Nature",
            "Text/Document",
            "Vehicle",
            "Food/Object",
            "Blue/Sky",
            "Green/Plant",
            "Dark/Night",
            "Bright/Light"
        ]
        
        # Train on synthetic features (in real project, use actual image dataset)
        self._train_simple_model()
        
        print("[ML] Model ready!")
        print("[ML] Categories: 10 scene/object types")
    
    def _train_simple_model(self):
        """Train model on synthetic data representing different scene types"""
        np.random.seed(42)
        
        # Generate synthetic training data (14 features per sample)
        # Features: color histograms, texture, brightness, etc.
        training_samples = []
        training_labels = []
        
        # Generate 50 samples per category
        for category_id in range(len(self.categories)):
            for _ in range(50):
                if category_id == 0:  # Person/Face - skin tones
                    features = self._generate_features(
                        r_mean=180, g_mean=140, b_mean=120,
                        brightness=150, edges=120, texture=80
                    )
                elif category_id == 1:  # Indoor
                    features = self._generate_features(
                        r_mean=140, g_mean=130, b_mean=120,
                        brightness=120, edges=90, texture=100
                    )
                elif category_id == 2:  # Outdoor/Nature
                    features = self._generate_features(
                        r_mean=100, g_mean=150, b_mean=80,
                        brightness=160, edges=100, texture=120
                    )
                elif category_id == 3:  # Text/Document
                    features = self._generate_features(
                        r_mean=240, g_mean=240, b_mean=235,
                        brightness=220, edges=180, texture=60
                    )
                elif category_id == 4:  # Vehicle
                    features = self._generate_features(
                        r_mean=100, g_mean=100, b_mean=110,
                        brightness=100, edges=140, texture=90
                    )
                elif category_id == 5:  # Food/Object
                    features = self._generate_features(
                        r_mean=160, g_mean=120, b_mean=80,
                        brightness=140, edges=100, texture=110
                    )
                elif category_id == 6:  # Blue/Sky
                    features = self._generate_features(
                        r_mean=100, g_mean=150, b_mean=220,
                        brightness=180, edges=60, texture=40
                    )
                elif category_id == 7:  # Green/Plant
                    features = self._generate_features(
                        r_mean=80, g_mean=180, b_mean=90,
                        brightness=130, edges=110, texture=130
                    )
                elif category_id == 8:  # Dark/Night
                    features = self._generate_features(
                        r_mean=40, g_mean=40, b_mean=50,
                        brightness=50, edges=70, texture=60
                    )
                else:  # Bright/Light
                    features = self._generate_features(
                        r_mean=230, g_mean=230, b_mean=220,
                        brightness=230, edges=50, texture=50
                    )
                
                training_samples.append(features)
                training_labels.append(category_id)
        
        X = np.array(training_samples)
        y = np.array(training_labels)
        
        # Train model
        X_scaled = self.scaler.fit_transform(X)
        self.model.fit(X_scaled, y)
        
        print(f"[ML] Trained on {len(training_samples)} samples")
    
    def _generate_features(self, r_mean, g_mean, b_mean, brightness, edges, texture):
        """Generate feature vector with some random variation"""
        return [
            r_mean + np.random.randn() * 20,      # Red channel mean
            g_mean + np.random.randn() * 20,      # Green channel mean
            b_mean + np.random.randn() * 20,      # Blue channel mean
            np.random.uniform(0, 100),            # Red std dev
            np.random.uniform(0, 100),            # Green std dev
            np.random.uniform(0, 100),            # Blue std dev
            brightness + np.random.randn() * 15,  # Overall brightness
            edges + np.random.randn() * 20,       # Edge density
            texture + np.random.randn() * 15,     # Texture complexity
            np.random.uniform(0, 1),              # Red-Green ratio
            np.random.uniform(0, 1),              # Blue-Red ratio
            np.random.uniform(0, 255),            # Min intensity
            np.random.uniform(0, 255),            # Max intensity
            np.random.uniform(0, 100),            # Contrast measure
        ]
    
    def _extract_features(self, frame):
        """Extract features from image for classification"""
        # Convert to different color spaces
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        # Color features (mean of each channel)
        b_mean = np.mean(frame[:, :, 0])
        g_mean = np.mean(frame[:, :, 1])
        r_mean = np.mean(frame[:, :, 2])
        
        # Color std deviations
        b_std = np.std(frame[:, :, 0])
        g_std = np.std(frame[:, :, 1])
        r_std = np.std(frame[:, :, 2])
        
        # Brightness
        brightness = np.mean(gray)
        
        # Edge detection for texture
        edges = cv2.Canny(gray, 50, 150)
        edge_density = np.sum(edges > 0) / edges.size * 100
        
        # Texture (using Laplacian variance)
        laplacian = cv2.Laplacian(gray, cv2.CV_64F)
        texture = np.var(laplacian)
        
        # Color ratios
        rg_ratio = r_mean / (g_mean + 1)
        br_ratio = b_mean / (r_mean + 1)
        
        # Intensity range
        min_intensity = np.min(gray)
        max_intensity = np.max(gray)
        contrast = np.std(gray)
        
        features = [
            r_mean, g_mean, b_mean,
            r_std, g_std, b_std,
            brightness,
            edge_density,
            texture,
            rg_ratio, br_ratio,
            min_intensity, max_intensity,
            contrast
        ]
        
        return np.array(features).reshape(1, -1)
    
    def classify(self, frame):
        """
        Classify image content using ML model
        Returns: List of (class_name, confidence) tuples
        """
        if not self.enabled or self.model is None:
            return []
        
        try:
            # Extract features
            features = self._extract_features(frame)
            features_scaled = self.scaler.transform(features)
            
            # Get prediction probabilities
            probabilities = self.model.predict_proba(features_scaled)[0]
            
            # Get top 3 predictions
            top_indices = np.argsort(probabilities)[-3:][::-1]
            
            results = []
            for idx in top_indices:
                category = self.categories[idx]
                confidence = probabilities[idx]
                results.append((category, float(confidence)))
            
            return results
            
        except Exception as e:
            print(f"[ML ERROR] Classification failed: {e}")
            return []


class ImageProcessor:
    def __init__(self):
        self.filters = {
            'grayscale': False,
            'edge_sobel': False,
            'edge_prewitt': False,
            'edge_laplacian': False,
            'blur': False,
            'gaussian_blur': False,
            'median_filter': False,
            'sharpen': False,
            'histogram_eq': False,
            'negative': False,
            'threshold': False,
            'sepia': False,
            'emboss': False,
            'fft_lowpass': False,
        }

        self.threshold_val = 128
        self.blur_ksize = 5
        self.gaussian_sigma = 1.5

    def apply_filters(self, frame):
        result = frame.copy()

        if self.filters['grayscale']:
            result = cv2.cvtColor(result, cv2.COLOR_BGR2GRAY)
            result = cv2.cvtColor(result, cv2.COLOR_GRAY2BGR)

        if self.filters['histogram_eq']:
            yuv = cv2.cvtColor(result, cv2.COLOR_BGR2YUV)
            yuv[:, :, 0] = cv2.equalizeHist(yuv[:, :, 0])
            result = cv2.cvtColor(yuv, cv2.COLOR_YUV2BGR)

        if self.filters['sepia']:
            kernel = np.array([
                [0.131, 0.534, 0.272],
                [0.168, 0.686, 0.349],
                [0.189, 0.769, 0.393]
            ])
            result = cv2.transform(result, kernel)
            result = np.clip(result, 0, 255).astype(np.uint8)

        if self.filters['blur']:
            result = cv2.blur(result, (self.blur_ksize, self.blur_ksize))

        if self.filters['gaussian_blur']:
            result = cv2.GaussianBlur(result, (5, 5), self.gaussian_sigma)

        if self.filters['median_filter']:
            result = cv2.medianBlur(result, 5)

        if self.filters['sharpen']:
            kernel = np.array([
                [0, -1, 0],
                [-1, 5, -1],
                [0, -1, 0]
            ])
            result = cv2.filter2D(result, -1, kernel)

        if self.filters['fft_lowpass']:
            result = self.fft_lowpass_filter(result)

        if self.filters['edge_sobel']:
            gray = cv2.cvtColor(result, cv2.COLOR_BGR2GRAY)
            sobelx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
            sobely = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
            magnitude = np.sqrt(sobelx ** 2 + sobely ** 2)
            magnitude = np.uint8(np.clip(magnitude, 0, 255))
            result = cv2.cvtColor(magnitude, cv2.COLOR_GRAY2BGR)

        if self.filters['edge_prewitt']:
            gray = cv2.cvtColor(result, cv2.COLOR_BGR2GRAY).astype(np.float64)
            kernelx = np.array([[-1, 0, 1], [-1, 0, 1], [-1, 0, 1]])
            kernely = np.array([[-1, -1, -1], [0, 0, 0], [1, 1, 1]])
            gx = cv2.filter2D(gray, -1, kernelx)
            gy = cv2.filter2D(gray, -1, kernely)
            magnitude = np.sqrt(gx ** 2 + gy ** 2)
            magnitude = np.uint8(np.clip(magnitude, 0, 255))
            result = cv2.cvtColor(magnitude, cv2.COLOR_GRAY2BGR)

        if self.filters['edge_laplacian']:
            gray = cv2.cvtColor(result, cv2.COLOR_BGR2GRAY)
            laplacian = cv2.Laplacian(gray, cv2.CV_64F)
            laplacian = np.uint8(np.clip(np.abs(laplacian), 0, 255))
            result = cv2.cvtColor(laplacian, cv2.COLOR_GRAY2BGR)

        if self.filters['emboss']:
            kernel = np.array([[-2, -1, 0], [-1, 1, 1], [0, 1, 2]])
            embossed = cv2.filter2D(result, cv2.CV_16S, kernel)
            embossed = embossed + 128
            result = np.clip(embossed, 0, 255).astype(np.uint8)

        if self.filters['threshold']:
            gray = cv2.cvtColor(result, cv2.COLOR_BGR2GRAY)
            _, binary = cv2.threshold(gray, self.threshold_val, 255, cv2.THRESH_BINARY)
            result = cv2.cvtColor(binary, cv2.COLOR_GRAY2BGR)

        if self.filters['negative']:
            result = 255 - result

        return result

    def fft_lowpass_filter(self, image):
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        rows, cols = gray.shape
        crow, ccol = rows // 2, cols // 2
        dft = np.fft.fft2(gray)
        dft_shift = np.fft.fftshift(dft)
        mask = np.zeros((rows, cols), np.uint8)
        radius = max(10, min(rows, cols) // 8)
        cv2.circle(mask, (ccol, crow), radius, 1, -1)
        filtered_shift = dft_shift * mask
        inverse_shift = np.fft.ifftshift(filtered_shift)
        img_back = np.fft.ifft2(inverse_shift)
        img_back = np.abs(img_back)
        img_back = np.clip(img_back, 0, 255).astype(np.uint8)
        return cv2.cvtColor(img_back, cv2.COLOR_GRAY2BGR)


def calculate_mse(original, processed):
    if original.shape != processed.shape:
        processed = cv2.resize(processed, (original.shape[1], original.shape[0]))
    original_float = original.astype(np.float64)
    processed_float = processed.astype(np.float64)
    mse = np.mean((original_float - processed_float) ** 2)
    return mse


def calculate_psnr(original, processed):
    mse = calculate_mse(original, processed)
    if mse == 0:
        return float('inf')
    psnr = 20 * np.log10(255.0 / np.sqrt(mse))
    return psnr


def create_histogram_panel(image, target_height=480, panel_width=320):
    panel = np.zeros((target_height, panel_width, 3), dtype=np.uint8)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    hist = cv2.calcHist([gray], [0], None, [256], [0, 256])
    hist = hist.flatten()

    mean_intensity = np.mean(gray)
    std_intensity = np.std(gray)
    min_intensity = np.min(gray)
    max_intensity = np.max(gray)

    cv2.putText(panel, "Histogram Analysis", (20, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 200, 255), 2)
    cv2.putText(panel, f"Mean: {mean_intensity:.2f}", (20, 60),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (220, 220, 220), 1)
    cv2.putText(panel, f"Std Dev: {std_intensity:.2f}", (20, 82),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (220, 220, 220), 1)
    cv2.putText(panel, f"Min: {min_intensity}  Max: {max_intensity}", (20, 104),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (220, 220, 220), 1)

    margin_left = 30
    margin_right = 15
    margin_top = 130
    margin_bottom = 35
    plot_w = panel_width - margin_left - margin_right
    plot_h = max(50, target_height - margin_top - margin_bottom)
    x_axis_y = margin_top + plot_h

    cv2.line(panel, (margin_left, margin_top), (margin_left, x_axis_y), (180, 180, 180), 1)
    cv2.line(panel, (margin_left, x_axis_y), (margin_left + plot_w, x_axis_y), (180, 180, 180), 1)

    if hist.max() > 0:
        hist_norm = hist / hist.max() * plot_h
    else:
        hist_norm = hist

    for i in range(1, 256):
        x1 = margin_left + int((i - 1) * plot_w / 255)
        y1 = x_axis_y - int(hist_norm[i - 1])
        x2 = margin_left + int(i * plot_w / 255)
        y2 = x_axis_y - int(hist_norm[i])
        cv2.line(panel, (x1, y1), (x2, y2), (0, 255, 100), 1)

    cv2.putText(panel, "0", (margin_left - 5, x_axis_y + 20),
                cv2.FONT_HERSHEY_SIMPLEX, 0.4, (180, 180, 180), 1)
    cv2.putText(panel, "255", (margin_left + plot_w - 25, x_axis_y + 20),
                cv2.FONT_HERSHEY_SIMPLEX, 0.4, (180, 180, 180), 1)

    return panel


def create_ml_panel(classifications, target_height=480, panel_width=320, ml_enabled=True):
    panel = np.zeros((target_height, panel_width, 3), dtype=np.uint8)
    
    cv2.putText(panel, "ML Classification", (20, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 100, 255), 2)
    
    if not ml_enabled:
        cv2.putText(panel, "scikit-learn not", (20, 80),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.45, (100, 100, 100), 1)
        cv2.putText(panel, "available", (20, 105),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.45, (100, 100, 100), 1)
        cv2.putText(panel, "Install with:", (20, 140),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (150, 150, 150), 1)
        cv2.putText(panel, "pip install", (20, 165),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (150, 150, 150), 1)
        cv2.putText(panel, "scikit-learn", (20, 185),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (150, 150, 150), 1)
        return panel
    
    cv2.putText(panel, "Model: Random Forest", (20, 55),
                cv2.FONT_HERSHEY_SIMPLEX, 0.4, (180, 180, 180), 1)
    cv2.putText(panel, "Features: 14 (color,", (20, 75),
                cv2.FONT_HERSHEY_SIMPLEX, 0.4, (180, 180, 180), 1)
    cv2.putText(panel, "texture, edges)", (20, 95),
                cv2.FONT_HERSHEY_SIMPLEX, 0.4, (180, 180, 180), 1)
    
    if not classifications:
        cv2.putText(panel, "Analyzing...", (20, 140),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (100, 100, 255), 1)
        return panel
    
    cv2.putText(panel, "Top Predictions:", (20, 130),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 200), 1)
    
    y_pos = 165
    for i, (class_name, confidence) in enumerate(classifications[:3]):
        display_name = class_name
        if len(display_name) > 18:
            display_name = display_name[:18] + "..."
        
        conf_percent = confidence * 100
        
        if conf_percent > 50:
            color = (0, 255, 0)
        elif conf_percent > 20:
            color = (0, 255, 255)
        else:
            color = (100, 100, 255)
        
        cv2.putText(panel, f"{i+1}.", (20, y_pos),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.45, (200, 200, 200), 1)
        cv2.putText(panel, display_name, (45, y_pos),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.42, color, 1)
        
        bar_x = 45
        bar_y = y_pos + 8
        bar_width = 230
        bar_height = 12
        
        cv2.rectangle(panel, (bar_x, bar_y), 
                     (bar_x + bar_width, bar_y + bar_height),
                     (60, 60, 60), -1)
        
        fill_width = int(bar_width * confidence)
        cv2.rectangle(panel, (bar_x, bar_y), 
                     (bar_x + fill_width, bar_y + bar_height),
                     color, -1)
        
        cv2.putText(panel, f"{conf_percent:.1f}%", (bar_x + bar_width + 5, y_pos),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)
        
        y_pos += 60
    
    cv2.putText(panel, "ML Algorithm:", (20, target_height - 80),
                cv2.FONT_HERSHEY_SIMPLEX, 0.38, (150, 150, 150), 1)
    cv2.putText(panel, "Random Forest", (20, target_height - 60),
                cv2.FONT_HERSHEY_SIMPLEX, 0.38, (150, 150, 150), 1)
    cv2.putText(panel, "10 scene categories", (20, target_height - 40),
                cv2.FONT_HERSHEY_SIMPLEX, 0.38, (150, 150, 150), 1)
    
    return panel


def draw_ui(frame, processor, source_text, ml_enabled, ml_active):
    overlay = frame.copy()
    cv2.rectangle(overlay, (10, 10), (360, 490), (0, 0, 0), -1)
    cv2.addWeighted(overlay, 0.65, frame, 0.35, 0, frame)

    cv2.putText(frame, "DIP Processing Lab + ML", (20, 40),
                cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 200, 255), 2)
    cv2.putText(frame, source_text, (20, 65),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (220, 220, 220), 1)
    cv2.putText(frame, "Press keys to toggle filters:", (20, 88),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (200, 200, 200), 1)

    controls = [
        ('G', 'grayscale', 'Grayscale'),
        ('S', 'edge_sobel', 'Sobel Edge'),
        ('P', 'edge_prewitt', 'Prewitt Edge'),
        ('L', 'edge_laplacian', 'Laplacian Edge'),
        ('B', 'blur', 'Box Blur'),
        ('V', 'gaussian_blur', 'Gaussian Blur'),
        ('M', 'median_filter', 'Median Filter'),
        ('H', 'sharpen', 'Sharpen'),
        ('E', 'histogram_eq', 'Histogram Eq.'),
        ('N', 'negative', 'Negative'),
        ('T', 'threshold', 'Threshold'),
        ('A', 'sepia', 'Sepia'),
        ('D', 'emboss', 'Emboss'),
        ('F', 'fft_lowpass', 'FFT Low Pass'),
    ]

    for i, (key, filter_name, label) in enumerate(controls):
        y = 115 + i * 22
        active = processor.filters[filter_name]
        color = (0, 255, 100) if active else (110, 110, 110)
        status = "ON" if active else "OFF"
        text = f"[{key}] {label}: {status}"
        cv2.putText(frame, text, (20, y), cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)

    y_ml = 115 + len(controls) * 22
    ml_color = (255, 100, 255) if ml_active else (110, 110, 110)
    ml_status = "ON" if ml_active else "OFF"
    ml_text = f"[C] ML Classification: {ml_status}"
    
    if not ml_enabled:
        ml_text = "[C] ML: Not Available"
        ml_color = (100, 100, 100)
    
    cv2.putText(frame, ml_text, (20, y_ml),
                cv2.FONT_HERSHEY_SIMPLEX, 0.4, ml_color, 1)

    cv2.putText(frame, "[W] Save Processed Image", (20, 455),
                cv2.FONT_HERSHEY_SIMPLEX, 0.4, (150, 255, 150), 1)
    cv2.putText(frame, "[R] Reset All   [Q] Quit", (20, 475),
                cv2.FONT_HERSHEY_SIMPLEX, 0.4, (150, 150, 255), 1)

    return frame


def draw_metrics(combined, start_x, mse, psnr):
    cv2.rectangle(combined, (start_x + 10, 10), (start_x + 300, 95), (0, 0, 0), -1)
    cv2.putText(combined, "Quantitative Evaluation", (start_x + 20, 35),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 200, 255), 2)
    cv2.putText(combined, f"MSE: {mse:.2f}", (start_x + 20, 60),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

    if np.isinf(psnr):
        psnr_text = "PSNR: infinite"
    else:
        psnr_text = f"PSNR: {psnr:.2f} dB"

    cv2.putText(combined, psnr_text, (start_x + 20, 82),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

    return combined


def resize_to_target_height(image, target_height):
    h, w = image.shape[:2]
    if h == target_height:
        return image
    ratio = target_height / float(h)
    new_w = int(w * ratio)
    return cv2.resize(image, (new_w, target_height))


def save_processed_image(processed, output_dir="outputs"):
    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"processed_{timestamp}.png"
    path = os.path.join(output_dir, filename)
    success = cv2.imwrite(path, processed)
    if success:
        print(f"  [SAVE] Processed image saved to: {path}")
    else:
        print("  [ERROR] Could not save image.")


def parse_arguments():
    parser = argparse.ArgumentParser(description="Real-Time Digital Image Processing Lab with ML")
    parser.add_argument("--image", "-i", type=str, default=None,
                        help="Path to image file. If not provided, webcam mode is used.")
    parser.add_argument("--camera", type=int, default=0,
                        help="Camera index for webcam mode. Default is 0.")
    parser.add_argument("--output-dir", type=str, default="outputs",
                        help="Directory where processed images will be saved.")
    parser.add_argument("--ml-off", action="store_true",
                        help="Start with ML classification disabled")
    return parser.parse_args()


def main():
    args = parse_arguments()

    processor = ImageProcessor()
    ml_classifier = MLClassifier()
    ml_active = not args.ml_off and ml_classifier.enabled
    
    if ml_classifier.enabled:
        print("[ML] Classification enabled. Press 'C' to toggle.")
    else:
        print("[ML] Classification unavailable. Install scikit-learn to enable.")

    cap = None
    source_image = None
    source_text = ""
    TARGET_HEIGHT = 480

    if args.image is not None:
        source_image = cv2.imread(args.image)
        if source_image is None:
            print(f"Error: Could not load image from disk: {args.image}")
            return
        source_image = resize_to_target_height(source_image, TARGET_HEIGHT)
        source_text = f"Source: Image File - {args.image}"
        print("=" * 60)
        print("  Real-Time DIP Processing Lab + ML")
        print("  Mode: Image File")
        print(f"  Loaded image: {args.image}")
        print("  Press C to toggle ML classification")
        print("  Press W to save processed result")
        print("  Press Q to quit")
        print("=" * 60)
    else:
        cap = cv2.VideoCapture(args.camera)
        if not cap.isOpened():
            print("Error: Cannot open webcam!")
            return
        source_text = f"Source: Webcam Camera {args.camera}"
        print("=" * 60)
        print("  Real-Time DIP Processing Lab + ML")
        print("  Mode: Webcam")
        print("  Press keys to toggle filters")
        print("  Press C to toggle ML classification")
        print("  Press W to save processed result")
        print("  Press Q to quit")
        print("=" * 60)

    cv2.namedWindow("DIP Processing Lab + ML", cv2.WINDOW_NORMAL)
    cv2.resizeWindow("DIP Processing Lab + ML", 1920, 520)

    last_processed = None
    last_classifications = []
    frame_count = 0

    while True:
        if source_image is not None:
            frame = source_image.copy()
        else:
            ret, frame = cap.read()
            if not ret:
                print("Error: Could not read frame.")
                break
            frame = resize_to_target_height(frame, TARGET_HEIGHT)

        processed = processor.apply_filters(frame)
        last_processed = processed.copy()

        if ml_active and frame_count % 15 == 0:
            last_classifications = ml_classifier.classify(frame)
        
        frame_count += 1

        mse = calculate_mse(frame, processed)
        psnr = calculate_psnr(frame, processed)

        display_original = draw_ui(frame.copy(), processor, source_text, 
                                   ml_classifier.enabled, ml_active)

        histogram_panel = create_histogram_panel(processed, 
                                                  target_height=TARGET_HEIGHT, 
                                                  panel_width=320)
        
        ml_panel = create_ml_panel(last_classifications if ml_active else [], 
                                   target_height=TARGET_HEIGHT, 
                                   panel_width=320,
                                   ml_enabled=ml_classifier.enabled)

        display_original = resize_to_target_height(display_original, TARGET_HEIGHT)
        processed = resize_to_target_height(processed, TARGET_HEIGHT)
        histogram_panel = resize_to_target_height(histogram_panel, TARGET_HEIGHT)
        ml_panel = resize_to_target_height(ml_panel, TARGET_HEIGHT)

        w1 = display_original.shape[1]
        w2 = processed.shape[1]
        w3 = histogram_panel.shape[1]

        combined = np.hstack([display_original, processed, histogram_panel, ml_panel])

        cv2.putText(combined, "ORIGINAL", (w1 // 2 - 50, TARGET_HEIGHT - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
        cv2.putText(combined, "PROCESSED", (w1 + w2 // 2 - 70, TARGET_HEIGHT - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
        cv2.putText(combined, "HISTOGRAM", (w1 + w2 + 95, TARGET_HEIGHT - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 100), 2)
        cv2.putText(combined, "AI VISION", (w1 + w2 + w3 + 95, TARGET_HEIGHT - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 100, 255), 2)

        combined = draw_metrics(combined, w1, mse, psnr)
        cv2.imshow("DIP Processing Lab + ML", combined)

        key = cv2.waitKey(1) & 0xFF
        if key == 255:
            continue

        try:
            key_char = chr(key).lower()
        except ValueError:
            key_char = ""

        key_map = {
            'g': 'grayscale', 's': 'edge_sobel', 'p': 'edge_prewitt',
            'l': 'edge_laplacian', 'b': 'blur', 'v': 'gaussian_blur',
            'm': 'median_filter', 'h': 'sharpen', 'e': 'histogram_eq',
            'n': 'negative', 't': 'threshold', 'a': 'sepia',
            'd': 'emboss', 'f': 'fft_lowpass',
        }

        if key_char in key_map:
            filter_name = key_map[key_char]
            processor.filters[filter_name] = not processor.filters[filter_name]
            status = "ON" if processor.filters[filter_name] else "OFF"
            print(f"  [{filter_name.upper()}] -> {status}")
        elif key_char == 'c':
            if ml_classifier.enabled:
                ml_active = not ml_active
                status = "ON" if ml_active else "OFF"
                print(f"  [ML CLASSIFICATION] -> {status}")
            else:
                print("  [ML] scikit-learn not available")
        elif key_char == 'r':
            for filter_name in processor.filters:
                processor.filters[filter_name] = False
            print("  [RESET] All filters disabled")
        elif key_char == 'w':
            if last_processed is not None:
                save_processed_image(last_processed, args.output_dir)
        elif key_char == 'q':
            break

    if cap is not None:
        cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()